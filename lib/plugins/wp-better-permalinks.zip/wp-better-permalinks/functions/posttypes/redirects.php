<?php

  class Redirects_Posttypes_WPBetterPermalinks {

    private $core;

    function __construct($core) {

      $this->core = $core;

    }

    /* ---
      Functions
    --- */

      public function addRedirect($postID, $old, $new) {

        $exists  = $this->core->posttypes->options['posts_redirects'];
        $old     = trim(parse_url($old, PHP_URL_PATH), '/');
        $new     = trim(parse_url($new, PHP_URL_PATH), '/');
        $current = isset($exists[$postID]) ? $exists[$postID]['current'] : '';

        if (($new == $old) && ($new == $current))
          return;

        $new = urldecode($new);
        $old = urldecode($old);
        $this->core->posttypes->save->saveRedirect($postID, $new, $old);

      }

      public function removeRedirect($postID) {

        unset($this->core->posttypes->options['posts_redirects'][$postID]);
        $this->core->posttypes->save->updateRedirects();

      }

  }