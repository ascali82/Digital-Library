<?php

  class Links_Posttypes_WPBetterPermalinks {

    private $core;

    function __construct($core) {

      $this->core = $core;

    }

    /* ---
      Actions
    --- */

      public function initActions() {

        add_filter('post_type_link', [$this, 'replaceLinks'], 100, 3);

      }

    /* ---
      Functions
    --- */

      public function replaceLinks($original, $post, $leavename) {

        if (!isset($this->core->posttypes->options['posts'][$post->ID]))
          return $original;

        $parts = explode('/', $this->core->posttypes->options['posts'][$post->ID]['regex']);
        $path  = array_slice($parts, 0, (count($parts) - 1));
        $slug  = !$leavename ? $post->post_name : '%postname%';
        $link  = str_replace(parse_url($original, PHP_URL_PATH), '/', $original);
        $link .= $path ? (implode('/', $path) . '/') : '';
        $link .= $slug . '/';

        return $link;

      }

  }