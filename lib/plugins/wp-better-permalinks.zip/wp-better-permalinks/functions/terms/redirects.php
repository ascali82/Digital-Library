<?php

  class Redirects_Terms_WPBetterPermalinks {

    private $core;

    function __construct($core) {

      $this->core = $core;

    }

    /* ---
      Functions
    --- */

      public function addRedirect($termID, $old, $new) {

        $exists  = $this->core->terms->options['terms_redirects'];
        $old     = trim(parse_url($old, PHP_URL_PATH), '/');
        $new     = trim(parse_url($new, PHP_URL_PATH), '/');
        $current = isset($exists[$termID]) ? $exists[$termID]['current'] : '';

        if (($new == $old) && ($new == $current))
          return;

        $new = urldecode($new);
        $old = urldecode($old);
        $this->core->terms->save->saveRedirect($termID, $new, $old);

      }

      public function removeRedirect($termID) {

        unset($this->core->terms->options['terms_redirects'][$termID]);
        $this->core->terms->save->updateRedirects();

      }

  }