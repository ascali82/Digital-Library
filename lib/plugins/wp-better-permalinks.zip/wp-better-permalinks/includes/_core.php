<div class="wrap wbsOptionPage">
  <h1 class="wp-heading-inline">
    <?= __('WP Better Permalinks settings', 'wp-better-permalinks'); ?>
  </h1>
  <div class="wbsOptionPage__columns">
    <div class="wbsOptionPage__column">
      <?php require_once 'settings.php'; ?>
    </div>
    <div class="wbsOptionPage__column">
      <?php require_once 'side.php'; ?>
    </div>
  </div>
</div>